// JavaScript Document

new KISSY.DataLazyload({diff: 500,});





