var $ = jQuery;
var url_forward=$('.showMsg').attr('data-url');
var ms=$('.showMsg').attr('data-url');
console.log(url_forward);
console.log(ms);
//setTimeout("redirect('url_forward');",ms);