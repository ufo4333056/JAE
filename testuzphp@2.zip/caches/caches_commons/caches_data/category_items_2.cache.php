<?php
return array (
  2 => '0',
);
?>