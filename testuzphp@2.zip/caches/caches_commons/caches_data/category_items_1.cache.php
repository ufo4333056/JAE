<?php
return array (
  1 => '0',
);
?>