<?php
return array (
  3 => '0',
);
?>