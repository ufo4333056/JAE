<?php defined('IN_JAE') or exit('No permission resources.'); ?><cajamodules include="kissy/1.3.0/core,kissy/gallery/layer-anim/1.1/index,kissy/gallery/datalazyload/1.0/index,jquery/1.9/index" />
<script src="http://a.tbcdn.cn/apps/taesite/libs/jquery-ui/jquery1.9.min.js"></script>
<script src="/statics/js/common.js"></script>
<?php $siteinfo=siteinfo(SITEID);  $site_setting=string2array($siteinfo['setting']); ?>
<link rel="stylesheet" href="/jae/templates/hubei3/css/mall.css" />

<div class="top wrap">
  <div class="logo"> <a href="/index.php"> <img  height="80" src="<?php echo $site_setting['head_logo'] ?>" /> </a> </div>
  <div class="top_right">
    <div class="member_btn">
      <div class="member_arrow" ><a href="/" target="_blank">��Ա����</a></div>
      <div class="member_mini_nav" >
        <div class="prompt"><span class="fl">���ã�<span class="tips"><a href="/member.php">���¼</a></span></span><span class="fr"></span></div>
        <div class="uclist">
          <ul class="fore1 fl">
            <?php $nav_arr=query('SELECT * FROM jae_member_menu WHERE display=1 AND project1=1 ORDER BY listorder,id ASC'); foreach ($nav_arr as $key =>
        $r) { ?>
            <li> <a  href="/index.php?m=<?php echo $r['m']?>&c=<?php echo $r['c']?>&a=<?php echo $r['a']?><?php if($r['data']) echo '&'.$r['data'];?>"><?php echo $r['name'] ?></a> </li>
            <?php } ?>
          </ul>
          <ul class="fore2 fl">
            <?php $nav_arr=query('SELECT * FROM jae_member_menu WHERE display=1 AND project1=0 ORDER BY listorder,id ASC'); foreach ($nav_arr as $key =>
        $r) { ?>
            <li> <a  href="/index.php?m=<?php echo $r['m']?>&c=<?php echo $r['c']?>&a=<?php echo $r['a']?><?php if($r['data']) echo '&'.$r['data'];?>"><?php echo $r['name'] ?>&nbsp;&gt;</a> </li>
            <?php } ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="top_point">
      <div class="member_point "> <a href="/index.php?m=point&c=index&a=sign&trad=all" target="_blank">0</a> </div>
      <div class="member_sign"> <a href="/index.php?m=member&c=index&a=init" target="_blank">���¼</a> </div>
    </div>
  </div>
</div>
<div class="wrap">
  <div class="nav">
    <ul >
      <li class="index"> <a href="/">��ҳ</a><span class="icon"></span> </li>
      <li> <a href="/index.php?m=prize&c=index&a=init">���ֳ齱</a> </li>
      <li> <a href="/index.php?m=exchange&c=index&a=init">���ֻ���</a> </li>
      <li> <a href="/index.php?m=seckill&c=index&a=init">������ɱ</a> </li>
      <li> <a href="/index.php?m=content&c=index&a=lists&catid=1">���ﷵ����</a> </li>
      <li> <a href="/index.php?m=point&c=index&a=point_invite">׬����</a> </li>
    </ul>
    <ul class="zdtfbr">
      <li> <a href="/index.php?m=member&c=index&a=goods_apply">��������</a> </li>
      <li> <a href="http://bangpai.taobao.com/group/thread/14715437-289148642.htm?spm=a216r.7118237.1.21.Cewgpk" target="_blank">�����ŵ</a> </li>
      <li> <a href="http://bangpai.taobao.com/group/thread/14715437-286960706.htm?spm=a216r.7118237.1.23.Cewgpk" target="_blank">����˵��</a> </li>
    </ul>
  </div>
</div>
<div class="cat">
  <div class="wrap"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" data-action=\"block\" data-datas=\"op=block&tag_md5=c0772b52f114eaaa4d8ac2bbff8ee7b4&pos=daihangweizilian\"><a href=\"/admin.php?m=visualization&c=block&a=init&op=block&tag_md5=c0772b52f114eaaa4d8ac2bbff8ee7b4&pos=daihangweizilian\" target=\"_blank\" class=\"admin_piao_edit\">EDIT</a>";}$block_tag = jae_base::load_app_class('block_tag', 'block');echo $block_tag->jae_tag(array('pos'=>'daihangweizilian',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '<div style=clear:both></div></div>';}?> </div>
</div>
