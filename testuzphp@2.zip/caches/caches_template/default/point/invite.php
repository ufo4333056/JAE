<?php defined('IN_JAE') or exit('No permission resources.'); ?><?php  
include template('content','head');
?>
<link href="/statics/css/invite.css" rel="stylesheet" type="text/css" />
<div class="page_content">

<div class="invite_content">

<div class="invite_copy">
<h2>���������ݸ��Ʒ��������ĺ��ѣ������������ĺ��ѳ�Ϊ��Ա��ÿ�ɹ�����һλ��Ա�����õ�<?php echo $data['point']?>���֣�</h2>
<textarea><?php echo $data['content_url']."\r\n".$siteinfo['domain']."index.php?fromuserid=".$memberinfo['userid']  ; ?></textarea>	
</div></div>


  
</div>
<!--
<div class="page_main">
<div class="add_point"><h1>׬����</h1><div class="add_sort"><ul><li>ǩ��</li><li>ǩ��</li><li>ǩ��</li><li>ǩ��</li><li>ǩ��</li><li>ǩ��</li></ul></div></div>
<div class="minus_point"><h1>������</h1><div class="minus_sort"><ul><li>ǩ��</li><li>ǩ��</li><li>ǩ��</li></ul></div></div>

<div class="sort1">
<div class="txt fl"></div><div class="img  style="display:block"fr" ></div>
</div>


</div>
-->
<div style=" position:relative; width:1190px; height:4500px; margin:0 auto; " >
<div  style="width:1920px; height:2000px; position:absolute; left:-365px;"><img  style="display:block" src="http://img02.taobaocdn.com/imgextra/i2/1089118323/TB257fxXVXXXXbNXXXXXXXXXXXX-1089118323.jpg" alt=" С�����ټ�2_02"/>
<a href="/index.php?m=point&c=index&a=sign" target="_blank"><img  style="display:block"src="http://img04.taobaocdn.com/imgextra/i4/1089118323/TB2YAfxXVXXXXaYXXXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/index.php?m=member&c=index&a=setinfo"><img  style="display:block"src="http://img02.taobaocdn.com/imgextra/i2/1089118323/TB2EkfxXVXXXXakXpXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/index.php?m=prize&c=index&a=init"><img  style="display:block"src="http://img02.taobaocdn.com/imgextra/i2/1089118323/TB2f7jxXVXXXXXCXXXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/index.php?m=content&c=index&a=lists&catid=1"><img  style="display:block"src="http://img02.taobaocdn.com/imgextra/i2/1089118323/TB2rQnxXVXXXXcvXXXXXXXXXXXX-1089118323.jpg"  border="0"/></a>
<a href="/index.php?m=point&c=index&a=point_invite"><img  style="display:block"src="http://img04.taobaocdn.com/imgextra/i4/1089118323/TB21QfxXVXXXXcQXXXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/"><img  style="display:block"src="http://img03.taobaocdn.com/imgextra/i3/1089118323/TB2AkfxXVXXXXb7XXXXXXXXXXXX-1089118323.jpg"  border="0"/></a>
<a href="/index.php?m=prize&c=index&a=init"><img  style="display:block"src="http://img04.taobaocdn.com/imgextra/i4/1089118323/TB2akjxXVXXXXX1XXXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/index.php?m=exchange&c=index&a=init"><img  style="display:block"src="http://img04.taobaocdn.com/imgextra/i4/1089118323/TB2NQfxXVXXXXbWXXXXXXXXXXXX-1089118323.jpg" border="0"/></a>
<a href="/index.php?m=seckill&c=index&a=init"><img  style="display:block"src="http://img02.taobaocdn.com/imgextra/i2/1089118323/TB2W7fxXVXXXXbqXXXXXXXXXXXX-1089118323.jpg"  border="0"/></a></div></div>