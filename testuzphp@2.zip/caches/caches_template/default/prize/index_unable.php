<?php defined('IN_JAE') or exit('No permission resources.'); ?><?php  
include template('content','head');
?>

<div class="i_step i_step1" style="height: 740px;
background: url(/statics/images/thanks_bg.png) no-repeat center 0 #F2445D;" >
  <div class="i_w990" style="width: 990px;
margin: 0 auto;
position: relative;"> <img style="display:block" src="/statics/images/thanks.png">
    <div  class="step_info" style="color: white;
display: block;
font-family: 'Microsoft Yahei', ΢���ź�, ����, ����;
font-size: 12px;
font-style: normal;
font-variant: normal;
font-weight: normal;
height: 96px;
left: 0px;
line-height: 18px;
margin-bottom: 0px;
margin-left: 0px;
margin-right: 0px;
margin-top: 0px;
padding-bottom: 0px;
padding-left: 0px;
padding-right: 0px;
padding-top: 0px;
position: absolute;
text-align: center;
top: 69px;
width: 990px;">
      <p class="h1" style="font-size: 58px;
font-weight: bold;
line-height: 60px;">������ﱸ��</p>
      <p class="h3" style="font-size: 24px;
line-height: 36px;" >��л���㣬����ʱ��ע�������ĵȴ�</p>
    </div>
  </div>
</div>
