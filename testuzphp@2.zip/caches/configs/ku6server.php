<?php
return array(
	//վ����Ƶ�ϴ��ӿڵ�ַ
	'api_url' => 'http://juhe.gcvideo.cn/v5/api',
	'api' => 'http://juhe.gcvideo.cn/api/',
	'player_url' => 'http://player.juhe.gcvideo.cn/player.php/vid/', 
);
?>