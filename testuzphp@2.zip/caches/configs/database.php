<?php
 
return array (
	'default' => array (
		'hostname' => 'localhost',
		'database' => 'hubei',
		'username' => 'root',
		'password' => '123456',
		'tablepre' => 'jae_',
		'charset' => 'gbk',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>