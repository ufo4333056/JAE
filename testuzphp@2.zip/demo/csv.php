<?php
    header( "Cache-Control: public" );
    header( "Pragma: public" );
    header("Content-type:application/vnd.ms-excel");
    header("Content-Disposition:attachment;filename=txxx.csv");
    header('Content-Type:APPLICATION/OCTET-STREAM');
?>
2,31,32131,23,123,1,23,12,3,123
1,2,3,45,,655,6,76,7,67,68,6,87,