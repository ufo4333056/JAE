var canvas=document.getElementById('myCanvas');
var ctx=canvas.getContext('2d');
ctx.fillStyle='#FFf000';
ctx.fillRect(0,0,80,100);
