<?php include $this->admin_tpl('head','admin');?>

member/index.php
<?php include $this->admin_tpl('foot','admin');?>