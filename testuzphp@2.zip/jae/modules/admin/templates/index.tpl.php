<link href="/statics/css/system.css" rel="stylesheet" type="text/css" />

<div class="header" style="width: auto; ">
	<div class="logo lf"><a href="/index.php" target="_blank"><span class="invisible">PHPCMS���ݹ���ϵͳ</span></a></div>
    <div class="rt-col">
    	<div class="tab_style white cut_line text-r"><a href="http://hubei.china.taobao.com" target="_blank">����֧�֣�������</a><span>|</span><a href="http://www.ehoneycomb.com" target="_blank">����Ȩ</a><span>|</span><a href="http://bbs.phpcms.cn" target="_blank">����ʱ��:2015-2-11</a>
    <ul id="Skin">
		<li class="s1 styleswitch" rel="styles1"></li>
		<li class="s2 styleswitch" rel="styles2"></li>
		<li class="s3 styleswitch" rel="styles3"></li>
        <li class="s4 styleswitch" rel="styles4"></li>
	</ul>
        </div>
    </div>
    <div class="col-auto" style="float:left;">
    	<div class="log white cut_line">���ã���ɫ�й�������  [��������Ա]<span>|</span>
    		<a href="/index.php" target="_blank" id="site_homepage">վ����ҳ</a><span>|</span>
    		<a href="/admin.php" target="_blank">��̨��ҳ</a><span>|</span>
    		
    	</div>
        <ul class="nav white" >
        <li id="_M10" class="top_menu"><a href="javascript:_M(10,'?m=admin&c=index&a=public_main')" hidefocus="true" style="outline:none;">�ҵ����</a></li><li id="_M1" class="top_menu on"><a href="javascript:_M(1,'?m=admin&c=setting&a=init')" hidefocus="true" style="outline:none;">����</a></li><li id="_M2" class="top_menu"><a href="javascript:_M(2,'?m=admin&c=module&a=init')" hidefocus="true" style="outline:none;">ģ��</a></li><li id="_M4" class="top_menu"><a href="javascript:_M(4,'?m=content&c=content&a=init')" hidefocus="true" style="outline:none;">����</a></li><li id="_M5" class="top_menu"><a href="javascript:_M(5,'?m=member&c=member&a=init')" hidefocus="true" style="outline:none;">�û�</a></li><li id="_M6" class="top_menu"><a href="javascript:_M(6,'?m=template&c=style&a=init')" hidefocus="true" style="outline:none;">����</a></li><li id="_M7" class="top_menu"><a href="/admin/admin.php?m=admin&c=extend&a=init_extend" hidefocus="true" style="outline:none;">��չ</a></li><li id="_M8" class="top_menu"><a href="javascript:_M(8,'?m=admin&c=phpsso&a=menu')" hidefocus="true" style="outline:none;">phpsso</a></li>            
        </ul>
    </div>
</div>
<div class="contents" style="width: auto; ">
	<div class="col-left left_menu">
    	<div id="Scroll" style="height: 381px; "><div id="leftMain"><h3 class="f14"><span class="switchs cu on" title="չ��������"></span>�������</h3><ul><li id="_MP64" class="sub_menu"><a href="javascript:_MP(64,'?m=admin&c=site&a=init');" hidefocus="true" style="outline:none;">վ�����</a></li><li id="_MP65" class="sub_menu"><a href="javascript:_MP(65,'?m=admin&c=release_point&a=init');" hidefocus="true" style="outline:none;">���������</a></li><li id="_MP959" class="sub_menu"><a href="javascript:_MP(959,'?m=admin&c=setting&a=init');" hidefocus="true" style="outline:none;">��������</a></li><li id="_MP979" class="sub_menu"><a href="javascript:_MP(979,'?m=admin&c=setting&a=init&&tab=2');" hidefocus="true" style="outline:none;">��ȫ����</a></li><li id="_MP980" class="sub_menu"><a href="javascript:_MP(980,'?m=admin&c=setting&a=init&&tab=3');" hidefocus="true" style="outline:none;">PHPSSO����</a></li><li id="_MP981" class="sub_menu"><a href="javascript:_MP(981,'?m=admin&c=setting&a=init&&tab=4');" hidefocus="true" style="outline:none;">��������</a></li><li id="_MP1093" class="sub_menu"><a href="javascript:_MP(1093,'?m=admin&c=setting&a=init&&tab=5');" hidefocus="true" style="outline:none;">connect</a></li></ul><h3 class="f14"><span class="switchs cu on" title="չ��������"></span>����Ա����</h3><ul><li id="_MP54" class="sub_menu"><a href="javascript:_MP(54,'?m=admin&c=admin_manage&a=init');" hidefocus="true" style="outline:none;">����Ա����</a></li><li id="_MP50" class="sub_menu"><a href="javascript:_MP(50,'?m=admin&c=role&a=init');" hidefocus="true" style="outline:none;">��ɫ����</a></li></ul></div></div>
        <a href="javascript:;" id="openClose" style="outline: invert none medium; height: 431px; " hidefocus="hidefocus" class="open" title="չ����ر�"><span class="hidden">չ��</span></a>
    </div>
	<div class="col-1 lf cat-menu" id="display_center_id" style="display: none; " height="100%">
	<div class="content">
        	<iframe name="center_frame" id="center_frame" src="?m=content&amp;c=content&amp;a=public_categorys&amp;type=add&amp;menuid=822&amp;pc_hash=NcwdoP" frameborder="false" scrolling="auto" style="border: none; height: 410px; " width="100%" height="auto" allowtransparency="true"></iframe>
            </div>
        </div>
    <div class="col-auto mr8">
    <div class="crumbs">
    <div class="shortcut cu-span"><a href="?m=content&amp;c=create_html&amp;a=public_index&amp;pc_hash=NcwdoP" target="right"><span>������ҳ</span></a><a href="?m=admin&amp;c=cache_all&amp;a=init&amp;pc_hash=NcwdoP" target="right"><span>���»���</span></a><a href="javascript:art.dialog({id:'map',iframe:'?m=admin&c=index&a=public_map', title:'��̨��ͼ', width:'700', height:'500', lock:true});void(0);"><span>��̨��ͼ</span></a></div>
    ��ǰλ�ã�<span id="current_pos">���� &gt; </span></div>
    	<div class="col-1">
        	<div class="content" style="position:relative; overflow:hidden">
                <div name="right" id="rightMain" src="?m=content&amp;c=content&amp;a=init&amp;menuid=822&amp;pc_hash=NcwdoP" frameborder="false" scrolling="auto" style="border: none; margin-bottom: 30px; height: 362px; " width="100%" height="auto" allowtransparency="true">12323
                
                
                  <iframe name="right" id="rightMain" src="http://ju.taobao.com" frameborder="false" scrolling="auto" style="border: none; margin-bottom: 30px; height: 362px; " width="100%" height="auto" allowtransparency="true"></iframe>
                
                
                
                
                
                
                </div>
                <div class="fav-nav">
					<div id="panellist">
											</div>
					<div id="paneladd"><a class="panel-add" href="javascript:add_panel();"><em>����</em></a></div>
					<input type="hidden" id="menuid" value="1">
					<input type="hidden" id="bigid" value="1">
                    <div id="help" class="fav-help" style=""></div>
				</div>
        	</div>
        </div>
    </div>
    <div class="clear"></div>
</div>