      
                
 </div>               </div>
                <div class="fav-nav">
					<div id="panellist">
											</div>
					<div id="paneladd"><a class="panel-add" href="javascript:add_panel();"><em>����</em></a></div>
					<input type="hidden" id="menuid" value="1">
					<input type="hidden" id="bigid" value="1">
                    <div id="help" class="fav-help" style=""></div>
				</div>
        	</div>
        </div>
    </div>
    <div class="clear"></div>
</div>