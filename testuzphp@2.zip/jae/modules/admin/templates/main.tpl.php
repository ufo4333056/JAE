<?php include $this->admin_tpl('head');?>


main.tpl.php
<?php include $this->admin_tpl('foot');?>