


UPDATE jae_site SET date='20140611' ;
UPDATE jae_site SET version='136';