

ALTER TABLE  jae_order  ADD goodsid INT(11) DEFAULT null AFTER  userid; 
UPDATE jae_site SET date='20140612' ;
UPDATE jae_site SET version='136';